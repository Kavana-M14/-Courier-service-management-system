# COURIER MANAGEMENT SYSTEM
## This is a Website of online courier management system
- Couriers are distinguished from ordinary mail services by features such as speed, security, tracking, signature, specialization and individualization of express services, and swift delivery times, which are optional for most everyday mail services. 
- As a premium service, couriers are usually more expensive than standard mail services, and their use is normally limited to packages where one or more of these features are considered important enough to warrant the cost.

#

## Some of the Shapshots
<br>

### 1. ER Diagram

<img width="395" alt="Courier  ER diagram" src="https://user-images.githubusercontent.com/75004804/130726455-f75dd62a-0276-43c3-9ba2-9e4ad9131fa0.png">
<br>

### 2. Web Pages ScreenShots
<br>

Home Page
![Screenshot (80)](https://user-images.githubusercontent.com/75004804/130727454-29b00c24-853c-44c4-b249-8057ad8b727c.png)
<br>

Login Page

![Screenshot (57)](https://user-images.githubusercontent.com/75004804/130727484-21c3e5cc-51af-456d-bb00-32e5024a0616.png)
<br>

Customer Order Details

![Screenshot (55)](https://user-images.githubusercontent.com/75004804/130727502-2dd328ac-d124-4c39-a424-fc292965d355.png)
<br>

Contact Us

![Screenshot (42)](https://user-images.githubusercontent.com/75004804/130727508-139d7901-6b4a-4cc9-a973-52d7ae8b0ab8.png)
<br>

<b>
 
## THANK YOU ❤ </b>
