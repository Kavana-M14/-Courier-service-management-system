<!-- copyright and contactUs fixed footer -->

<!DOCTYPE html>
<html>
<head>
<style>
.footer {
    position: fixed;
    width: 100%;
    text-align: center;
    
    bottom: 0;
    background-color: #2ab7ca;
    color: white;
}
</style>
</head>
<body>
<footer class="footer">

  <p style="margin-top: 4px;margin-bottom:-10px">By Kavya Hegde and Kavana M</p><br>
  <a href="mailto:hegde02@gmail.com" style="color:brown">ContactUs</a>

</footer>

</body>
</html>
