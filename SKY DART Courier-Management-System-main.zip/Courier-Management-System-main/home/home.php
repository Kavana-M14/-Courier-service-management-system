<?php

session_start();
if(isset($_SESSION['uid'])){
    echo "";
    }else{
    header('location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style> @import url('https://fonts.googleapis.com/css2?family=Caveat&family=Dancing+Script:wght@400;700&family=Moon+Dance&family=Pacifico&family=Poppins:ital,wght@1,300&family=Rubik+Gemstones&family=Shadows+Into+Light&display=swap'); </style>
    <style>
        body
        {
        background-image:url('https://myudaipurcity.com/wp-content/uploads/2019/01/Courier-Services-in-Udaipur.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        }
        h3{
            font-family:'Caveat';
            font-size:40px;
        }
    </style>
</head>
<body>
    <?php include('header.php'); ?>
    <div align='center' style="font-weight: bold;font-family:'Times New Roman', Times, serif"><br><br><br><br>
       <div><h1 style="font-size:75px;text-shadow:5px 3px 2px grey">Welcome to Sky Dart Courier Management Service</h1></div> 
        <h3>The fastest courier service of India</h3><br><br>
        <h3 style="font-family:'Moon Dance'font-weight:bold ;">DBMS MINI PROJECT</h3>
        
    </div>
</body>
</html>