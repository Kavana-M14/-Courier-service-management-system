<?php
session_start();
if(isset($_SESSION['uid'])){
    echo "";
    }else{
    header('location: ../index.php');
    }

?>
<?php
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing</title>
</head>
<style>

</style>

<body>
    <table width='30%' border="5px solid" style="margin-top:30px;margin-left:auto ;margin-right:auto ;font-weight:bold;border-spacing: 5px 5px;border-collapse: collapse;">
    <tr style="background-color: green;font-size:30px">
    <th>Weight in Kg</th><th>Price</th>
    </tr>
    <tr>
    <td class="c">0-1</td class="c"><td>120</td>
    </tr>
    <tr>
    <td class="c">1-2</td><td class="c">200</td>
    </tr>
    <tr>
    <td class="c">2-4</td><td class="c">250</td>
    </tr>
    <tr>
    <td class="c">4-5</td><td class="c">300</td>
    </tr>
    <tr>
    <td class="c">5-7</td><td class="c">400</td>
    </tr>
    <tr>
    <td class="c">7-above</td class="c"><td>500</td>
    </tr>
    </table>
    <h3 align="center" style="margin-top:20px;"> As per your courier's weight pay the amount on:</h3>
    <div style="margin-left:45% ;margin-right:auto ;font-weight:bold;">
    <ol>
    <li>UPI: abcd@sbi.com</li>
    <li>GPay: 6362786223</li>
    <li>PhnPay: 3565656555</li>
    </ol>
    </div>
</body>
</html>